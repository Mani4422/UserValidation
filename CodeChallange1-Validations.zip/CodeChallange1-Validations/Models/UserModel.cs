﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

using CodeChallange1_Validations.Attributes;

namespace CodeChallange1_Validations.Models
{
    public class UserModel
    {

        [Required(ErrorMessage="Please Enter Name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Please Enter User Name")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Please Enter Password")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Please Enter Confirm Password")]
        [Compare("Password",    ErrorMessage = "Confirm Password doesn't match")]
        public string ConfirmPassword { get; set; }

        [Required(ErrorMessage = "Please Enter Contact")]
        [RegularExpression("^[6,7,8,9]\\d{9}$", ErrorMessage = "Please enter corect phone number")]
        public string Contact { get; set; }

        [Required(ErrorMessage = "Please select country")]
        public string Country { get; set; }

        [Required(ErrorMessage = "Please select city")]
        public string City { get; set; }

        [Required(ErrorMessage = "Please Select Gender")]
        public bool Gender { get; set; }

       
        [ValidateCheckBox(ErrorMessage="Please Accept the terms")]
        [DisplayName("Accept terms and conditions")]
        public bool TermsAccepted { get; set; }

    }
}
