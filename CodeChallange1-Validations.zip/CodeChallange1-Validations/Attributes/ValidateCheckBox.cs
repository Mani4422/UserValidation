﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace CodeChallange1_Validations.Attributes
{
    public class ValidateCheckBox: ValidationAttribute, IClientModelValidator
    {
        public void AddValidation(ClientModelValidationContext context)
        {
            // throw new NotImplementedException();
            context.Attributes.Add("data-val-checkbox", ErrorMessage);
        }

        public override bool IsValid(object value)
        {
            return value != null && value is bool && (bool)value;
        }

        //public override object IsValid(object value)
        //{
        //    return (bool)value;

        //    //if ((bool)value == true)
        //    //    return true;
        //    //else
        //    //    return null;

        //}
    }
}
